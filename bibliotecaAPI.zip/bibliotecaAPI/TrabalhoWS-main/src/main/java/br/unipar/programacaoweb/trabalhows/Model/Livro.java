package br.unipar.programacaoweb.trabalhows.Model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Livro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(length = 50)
    private String titulo;

    @Column(length = 30)
    private String arquivo;

    @Column(length = 110)
    private String autor;

    @Column(length = 15)
    private String clasificacao_etaria;

    @Column(length = 110)
    private Integer estante_id;

    @Column(length = 15)
    private Boolean lendo;
}
